import { useCallback, useEffect, useRef, useState } from "react";

function createAmbientEngine() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;
  const ctx = new AudioCtx();

  const master = ctx.createGain();
  master.gain.value = 0.12;
  master.connect(ctx.destination);

  const filter = ctx.createBiquadFilter();
  filter.type = "lowpass";
  filter.frequency.value = 800;
  filter.Q.value = 0.8;
  filter.connect(master);

  const voices = [];

  function addVoice(freq, detune = 0) {
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.value = freq;
    osc.detune.value = detune;

    const gain = ctx.createGain();
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(filter);

    // Gentle breathing via LFO.
    const lfo = ctx.createOscillator();
    lfo.type = "sine";
    lfo.frequency.value = 0.06 + Math.random() * 0.05;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.06;
    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);

    voices.push({ osc, gain, lfo, lfoGain });
  }

  // Soft pad chord
  addVoice(220, -8);
  addVoice(277.18, 6);
  addVoice(329.63, -4);

  let started = false;

  function start() {
    if (started) return;
    started = true;
    voices.forEach((v, idx) => {
      v.osc.start();
      v.lfo.start();
      const now = ctx.currentTime;
      v.gain.gain.cancelScheduledValues(now);
      v.gain.gain.setValueAtTime(0, now);
      v.gain.gain.linearRampToValueAtTime(0.32 - idx * 0.08, now + 3.5);
    });
  }

  function stop() {
    if (!started) return;
    const now = ctx.currentTime;
    voices.forEach((v) => {
      v.gain.gain.cancelScheduledValues(now);
      v.gain.gain.setValueAtTime(v.gain.gain.value, now);
      v.gain.gain.linearRampToValueAtTime(0, now + 1.2);
    });
    started = false;
  }

  function setMuted(m) {
    master.gain.value = m ? 0 : 0.12;
  }

  return { ctx, start, stop, setMuted };
}

export function useAmbientMusic() {
  const engineRef = useRef(null);
  const [enabled, setEnabled] = useState(false);
  const [muted, setMuted] = useState(false);

  const ensureEngine = useCallback(() => {
    if (!engineRef.current) engineRef.current = createAmbientEngine();
    return engineRef.current;
  }, []);

  const toggleEnabled = useCallback(async () => {
    const next = !enabled;
    setEnabled(next);
    const engine = ensureEngine();
    if (engine.ctx.state === "suspended") {
      try {
        await engine.ctx.resume();
      } catch {
        // ignore
      }
    }
    if (next) engine.start();
    else engine.stop();
  }, [enabled, ensureEngine]);

  useEffect(() => {
    if (!engineRef.current) return;
    engineRef.current.setMuted(muted);
  }, [muted]);

  useEffect(() => {
    return () => {
      // Best-effort cleanup; many browsers ignore closing audio contexts.
      try {
        engineRef.current?.ctx?.close?.();
      } catch {
        // ignore
      }
    };
  }, []);

  return { enabled, muted, setMuted, toggleEnabled };
}

