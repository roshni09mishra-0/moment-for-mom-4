import { useMemo } from "react";
import { motion } from "framer-motion";
import { Heart } from "lucide-react";

function rand(min, max) {
  return Math.random() * (max - min) + min;
}

export function FloatingHearts() {
  const hearts = useMemo(() => {
    return Array.from({ length: 14 }).map((_, i) => ({
      id: i,
      left: rand(0, 100),
      size: rand(16, 34),
      duration: rand(10, 18),
      delay: rand(0, 6),
      opacity: rand(0.12, 0.26),
      hue: i % 3,
    }));
  }, []);

  const colors = [
    "text-blush-400/60",
    "text-lavender-400/55",
    "text-mint-400/50",
  ];

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {hearts.map((h) => (
        <motion.div
          key={h.id}
          className="absolute -bottom-16"
          style={{ left: `${h.left}%`, opacity: h.opacity }}
          initial={{ y: 40, rotate: rand(-10, 10), scale: 0.9 }}
          animate={{ y: ["0vh", "-115vh"], x: [0, rand(-50, 50)], rotate: [0, rand(-35, 35)] }}
          transition={{
            duration: h.duration,
            repeat: Infinity,
            ease: "linear",
            delay: h.delay,
          }}
        >
          <Heart
            className={colors[h.hue]}
            style={{ width: h.size, height: h.size, filter: "drop-shadow(0 0 18px rgba(255,63,134,.18))" }}
            fill="currentColor"
          />
        </motion.div>
      ))}
    </div>
  );
}

