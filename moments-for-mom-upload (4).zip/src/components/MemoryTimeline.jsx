import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { CalendarDays, Plus } from "lucide-react";

const seed = [
  { year: "Childhood", title: "Tiny hands, endless love", body: "She held the world steady while I learned to walk." },
  { year: "School days", title: "Every small victory", body: "She celebrated my effort, not just the result." },
  { year: "Growing up", title: "Quiet sacrifices", body: "She gave without asking to be seen — but I see her now." },
  { year: "Today", title: "Gratitude, finally said out loud", body: "I’m becoming who I am because she never stopped loving me." },
];

export function MemoryTimeline() {
  const [extra, setExtra] = useState([]);
  const [year, setYear] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const items = useMemo(() => {
    const mapped = extra.map((x) => ({ ...x, custom: true }));
    return [...seed, ...mapped];
  }, [extra]);

  function add() {
    const y = year.trim();
    const t = title.trim();
    const b = body.trim();
    if (!y || !t || !b) return;
    setExtra((p) => [{ year: y, title: t, body: b }, ...p].slice(0, 6));
    setYear("");
    setTitle("");
    setBody("");
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div className="lg:col-span-2 rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5">
          <div className="text-left">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Memory Timeline</h3>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
              A gentle path through the moments that shaped your heart.
            </p>
          </div>

          <div className="mt-6 relative">
            <div className="absolute left-3 top-0 bottom-0 w-px bg-gradient-to-b from-blush-400/50 via-lavender-400/30 to-mint-400/40" />
            <div className="space-y-5">
              {items.map((it, idx) => (
                <motion.div
                  key={`${it.year}-${it.title}-${idx}`}
                  initial={{ opacity: 0, y: 14 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-80px" }}
                  transition={{ duration: 0.5, delay: idx * 0.03 }}
                  className="relative pl-10"
                >
                  <div className="absolute left-0 top-1.5 h-6 w-6 rounded-full bg-gradient-to-br from-blush-400 via-lavender-400 to-mint-300 shadow-[0_0_0_6px_rgba(255,255,255,.55)] dark:shadow-[0_0_0_6px_rgba(2,6,23,.65)]" />
                  <div className="rounded-2xl border border-white/60 bg-white/55 p-5 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="inline-flex items-center gap-2 rounded-full bg-slate-900/5 px-3 py-1 text-xs font-semibold text-slate-700 dark:bg-white/10 dark:text-slate-200">
                        <CalendarDays size={14} className="text-blush-500" />
                        {it.year}
                      </span>
                      {it.custom ? (
                        <span className="rounded-full border border-white/50 bg-white/40 px-3 py-1 text-xs font-semibold text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                          Added by you
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-3 text-base font-semibold text-slate-900 dark:text-white">{it.title}</div>
                    <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">{it.body}</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5">
          <div className="text-left">
            <h4 className="text-base font-semibold text-slate-900 dark:text-white">Add a memory</h4>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">Write one moment you never want to forget.</p>
          </div>

          <div className="mt-4 space-y-3">
            <input
              value={year}
              onChange={(e) => setYear(e.target.value)}
              placeholder="When? (e.g., 2014 / Childhood)"
              className="w-full rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Title"
              className="w-full rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Describe the memory..."
              rows={4}
              className="w-full resize-none rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <button
              type="button"
              onClick={add}
              className="group relative inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60"
            >
              <Plus size={18} />
              Add to timeline
              <span className="absolute inset-0 rounded-2xl opacity-0 transition-opacity group-hover:opacity-100">
                <span className="shine absolute inset-0 rounded-2xl" />
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

