import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Mic, Square, Upload, Volume2 } from "lucide-react";

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function VoiceMessage() {
  const [recording, setRecording] = useState(false);
  const [supported, setSupported] = useState(false);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);

  const [clips, setClips] = useState([]); // {id, url, name}
  const [playingId, setPlayingId] = useState(null);
  const audioRef = useRef(null);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    setSupported(typeof window !== "undefined" && !!navigator.mediaDevices?.getUserMedia);
  }, []);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;

    const onTime = () => setTime(a.currentTime || 0);
    const onMeta = () => setDuration(a.duration || 0);
    const onEnd = () => setPlayingId(null);
    a.addEventListener("timeupdate", onTime);
    a.addEventListener("loadedmetadata", onMeta);
    a.addEventListener("ended", onEnd);
    return () => {
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("loadedmetadata", onMeta);
      a.removeEventListener("ended", onEnd);
    };
  }, [playingId]);

  async function start() {
    if (!supported) return;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    recorderRef.current = recorder;
    chunksRef.current = [];
    recorder.ondataavailable = (e) => {
      if (e.data.size) chunksRef.current.push(e.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: recorder.mimeType });
      const url = URL.createObjectURL(blob);
      setClips((p) => [
        {
          id: `clip-${Date.now()}-${Math.random().toString(16).slice(2)}`,
          url,
          name: `Voice message ${new Date().toLocaleString()}`,
        },
        ...p,
      ]);
      stream.getTracks().forEach((t) => t.stop());
    };
    recorder.start();
    setRecording(true);
  }

  function stop() {
    recorderRef.current?.stop?.();
    setRecording(false);
  }

  function onUpload(files) {
    const next = Array.from(files).map((f) => ({
      id: `upload-${f.name}-${f.size}-${f.lastModified}`,
      url: URL.createObjectURL(f),
      name: f.name,
    }));
    setClips((p) => [...next, ...p].slice(0, 8));
  }

  function play(clip) {
    setPlayingId(clip.id);
    setTimeout(() => {
      if (!audioRef.current) return;
      audioRef.current.src = clip.url;
      audioRef.current.play().catch(() => {});
    }, 0);
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="text-left">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Voice Message</h3>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
              Record a quick “I love you, Mom” — or upload an audio clip.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={recording ? stop : start}
              className="group relative inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60 disabled:opacity-60 disabled:hover:translate-y-0"
              disabled={!supported}
            >
              {recording ? <Square size={18} /> : <Mic size={18} />}
              {recording ? "Stop" : "Record"}
              <span className="absolute inset-0 rounded-full opacity-0 transition-opacity group-hover:opacity-100">
                <span className="shine absolute inset-0 rounded-full" />
              </span>
            </button>

            <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-white/60 bg-white/60 px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm backdrop-blur transition hover:bg-white/70 dark:border-white/10 dark:bg-white/5 dark:text-white">
              <Upload size={18} />
              Upload audio
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.length) onUpload(e.target.files);
                  e.target.value = "";
                }}
              />
            </label>
          </div>
        </div>

        {!supported ? (
          <div className="mt-4 rounded-2xl border border-white/60 bg-white/60 p-4 text-left text-sm text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
            Microphone recording isn’t available in this browser/context — you can still upload an audio file.
          </div>
        ) : null}

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          <div className="rounded-2xl border border-white/60 bg-white/60 p-5 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/5">
            <div className="flex items-center justify-between">
              <div className="text-left text-sm font-semibold text-slate-900 dark:text-white">Player</div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                {formatTime(time)} / {formatTime(duration || 0)}
              </div>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-blush-300 via-lavender-300 to-mint-200 text-slate-900 shadow-sm">
                <Volume2 size={18} />
              </div>
              <div className="flex-1">
                <audio ref={audioRef} controls className="w-full" />
              </div>
            </div>
            <div className="mt-3 text-left text-xs text-slate-500 dark:text-slate-400">
              Tip: record something short and sweet — a voice hug.
            </div>
          </div>

          <div className="rounded-2xl border border-white/60 bg-white/60 p-5 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/5">
            <div className="text-left text-sm font-semibold text-slate-900 dark:text-white">Your clips</div>
            <AnimatePresence initial={false}>
              <div className="mt-3 space-y-2">
                {clips.length ? (
                  clips.map((c) => (
                    <motion.button
                      key={c.id}
                      type="button"
                      onClick={() => play(c)}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="w-full rounded-2xl border border-white/60 bg-white/70 px-4 py-3 text-left text-sm font-medium text-slate-900 shadow-sm transition hover:-translate-y-0.5 hover:shadow-glow dark:border-white/10 dark:bg-white/5 dark:text-white dark:hover:shadow-glowDark"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="truncate">{c.name}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          {playingId === c.id ? "Playing…" : "Tap to play"}
                        </div>
                      </div>
                    </motion.button>
                  ))
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="rounded-2xl border border-dashed border-white/70 bg-white/40 p-5 text-left text-sm text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300"
                  >
                    No clips yet — record one, or upload an audio file.
                  </motion.div>
                )}
              </div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}

