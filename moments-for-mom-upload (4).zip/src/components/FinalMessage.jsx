import { motion } from "framer-motion";
import { Heart, Sparkles } from "lucide-react";

export function FinalMessage() {
  return (
    <div className="mx-auto max-w-6xl">
      <div className="relative overflow-hidden rounded-3xl border border-white/60 bg-white/50 shadow-[0_45px_120px_-85px_rgba(255,63,134,.7)] backdrop-blur p-8 sm:p-12 dark:border-white/10 dark:bg-white/5 dark:shadow-[0_55px_140px_-90px_rgba(134,94,255,.75)]">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(700px_400px_at_15%_25%,rgba(255,63,134,.22),transparent_60%),radial-gradient(800px_450px_at_85%_30%,rgba(134,94,255,.18),transparent_55%),radial-gradient(650px_420px_at_40%_95%,rgba(23,242,173,.12),transparent_60%)]" />

        <div className="mx-auto max-w-3xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="inline-flex items-center gap-2 rounded-full border border-white/60 bg-white/50 px-4 py-2 text-xs font-semibold text-slate-700 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
          >
            <Sparkles size={16} className="text-blush-500" />
            One last thing…
          </motion.div>

          <motion.h3
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.05 }}
            className="mt-5 text-balance text-3xl sm:text-4xl font-semibold tracking-tight text-slate-900 dark:text-white"
          >
            If love had a face, it would look like the way my mom shows up.
          </motion.h3>

          <motion.p
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.12 }}
            className="mt-4 text-pretty text-base sm:text-lg text-slate-600 dark:text-slate-300"
          >
            To every mother, caregiver, and gentle heart — thank you for the unseen work, the endless patience, and the
            love that keeps growing.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.18 }}
            className="mx-auto mt-8 inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-6 py-3 text-sm font-semibold text-white shadow-glow"
          >
            <Heart size={18} fill="currentColor" />
            Happy Mother’s Day, Mom.
          </motion.div>
        </div>
      </div>
    </div>
  );
}

