import { motion } from "framer-motion";
import { Sparkles, Upload, Wand2 } from "lucide-react";
import { cn } from "../lib/utils";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.045, delayChildren: 0.15 },
  },
};

const letter = {
  hidden: { opacity: 0, y: 16, rotate: -2 },
  show: { opacity: 1, y: 0, rotate: 0, transition: { duration: 0.55, ease: "easeOut" } },
};

export function Hero() {
  const text = "Thank You Mom ❤️";

  return (
    <header id="top" className="relative">
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 pt-14 sm:pt-20 pb-12 sm:pb-16">
        <div className="relative overflow-hidden rounded-3xl border border-white/50 bg-white/50 shadow-[0_30px_80px_-50px_rgba(255,63,134,.55)] backdrop-blur-xl dark:border-white/10 dark:bg-white/5 dark:shadow-[0_40px_100px_-60px_rgba(134,94,255,.6)]">
          <div className="absolute inset-0 -z-10 bg-[radial-gradient(900px_500px_at_10%_10%,rgba(255,63,134,.22),transparent_60%),radial-gradient(800px_500px_at_90%_15%,rgba(134,94,255,.18),transparent_55%),radial-gradient(700px_450px_at_40%_95%,rgba(23,242,173,.12),transparent_60%)]" />
          <div className="p-8 sm:p-12 lg:p-14">
            <div className="flex flex-col items-center text-center">
              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: "easeOut" }}
                className="inline-flex items-center gap-2 rounded-full border border-white/50 bg-white/60 px-4 py-2 text-xs font-semibold tracking-wide text-slate-700 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
              >
                <Sparkles size={16} className="text-blush-500" />
                A soft, emotional Mother’s Day experience
              </motion.div>

              <motion.h1
                variants={container}
                initial="hidden"
                animate="show"
                className="mt-6 text-balance text-4xl sm:text-6xl font-semibold tracking-tight"
                aria-label={text}
              >
                {text.split("").map((ch, idx) => (
                  <motion.span
                    key={`${ch}-${idx}`}
                    variants={letter}
                    className={cn(
                      "inline-block",
                      ch === " " ? "w-2 sm:w-3" : "",
                      ch === "❤️" ? "ml-1" : ""
                    )}
                  >
                    <span className={idx < 8 ? "gradient-text" : "text-slate-900 dark:text-white"}>
                      {ch}
                    </span>
                  </motion.span>
                ))}
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.75, ease: "easeOut", delay: 0.25 }}
                className="mt-4 max-w-2xl text-pretty text-base sm:text-lg text-slate-600 dark:text-slate-300"
              >
                Collect memories, share love, and create something your mom will feel in her heart — with smooth animations,
                pastel glow, and little surprises along the way.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: "easeOut", delay: 0.35 }}
                className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-3"
              >
                <a
                  href="#gallery"
                  className="group relative inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-6 py-3 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 hover:shadow-[0_25px_70px_-25px_rgba(255,63,134,.75)] focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60"
                >
                  <Upload size={18} />
                  Add photo memories
                  <span className="absolute inset-0 rounded-full opacity-0 transition-opacity group-hover:opacity-100">
                    <span className="shine absolute inset-0 rounded-full" />
                  </span>
                </a>
                <a
                  href="#card"
                  className="group inline-flex items-center justify-center gap-2 rounded-full border border-white/60 bg-white/60 px-6 py-3 text-sm font-semibold text-slate-900 shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:shadow-glow focus:outline-none focus-visible:ring-2 focus-visible:ring-lavender-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:hover:shadow-glowDark"
                >
                  <Wand2 size={18} />
                  Make a greeting card
                </a>
              </motion.div>

              <div className="mt-10 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span className="h-1.5 w-1.5 rounded-full bg-blush-400/70" />
                Tip: Music starts after you click “Music” (browser autoplay rules).
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

