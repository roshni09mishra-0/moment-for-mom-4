import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { HeartHandshake, Plus, Sparkle, Star, Sun } from "lucide-react";

const seedReasons = [
  { icon: HeartHandshake, title: "She’s my safe place", body: "The kind of comfort you feel before you even speak." },
  { icon: Sparkle, title: "Her love is magic", body: "She turns ordinary moments into something worth remembering." },
  { icon: Sun, title: "She believes in me", body: "Even when I’m doubting myself, she doesn’t." },
  { icon: Star, title: "She inspires my strength", body: "Soft heart, strong soul — she shows me how." },
];

export function Reasons() {
  const [extra, setExtra] = useState([]);
  const [text, setText] = useState("");

  const cards = useMemo(() => {
    const custom = extra.map((t) => ({
      icon: Sparkle,
      title: t,
      body: "Because some love doesn’t need an explanation — it just exists.",
      custom: true,
    }));
    return [...seedReasons, ...custom];
  }, [extra]);

  function add() {
    const t = text.trim();
    if (!t) return;
    setExtra((p) => [t, ...p].slice(0, 8));
    setText("");
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="text-left">
          <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Reasons I Love My Mom</h3>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Little truths, big feelings — hover for glow and softness.
          </p>
        </div>

        <div className="flex w-full sm:w-auto items-center gap-2">
          <div className="flex-1 sm:w-72">
            <label className="sr-only" htmlFor="reason">
              Add a reason
            </label>
            <input
              id="reason"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Add your own reason…"
              className="w-full rounded-full border border-white/60 bg-white/60 px-4 py-2.5 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
          </div>
          <button
            type="button"
            onClick={add}
            className="group relative inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60"
          >
            <Plus size={18} />
            Add
            <span className="absolute inset-0 rounded-full opacity-0 transition-opacity group-hover:opacity-100">
              <span className="shine absolute inset-0 rounded-full" />
            </span>
          </button>
        </div>
      </div>

      <div className="mt-7 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c, i) => {
          const Icon = c.icon;
          return (
            <motion.div
              key={`${c.title}-${i}`}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.04 }}
              className="group relative overflow-hidden rounded-3xl border border-white/60 bg-white/50 p-5 shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-glow dark:border-white/10 dark:bg-white/5 dark:hover:shadow-glowDark"
            >
              <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gradient-to-br from-blush-400/25 to-lavender-400/20 blur-2xl transition-opacity group-hover:opacity-100 dark:from-blush-400/20 dark:to-lavender-400/10" />
              <div className="relative flex items-start gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-blush-300 via-lavender-300 to-mint-200 text-slate-900 shadow-sm">
                  <Icon size={18} />
                </div>
                <div className="text-left">
                  <div className="text-base font-semibold text-slate-900 dark:text-white">{c.title}</div>
                  <div className="mt-1 text-sm text-slate-600 dark:text-slate-300">{c.body}</div>
                </div>
              </div>

              {c.custom ? (
                <div className="relative mt-4 inline-flex items-center gap-2 rounded-full border border-white/50 bg-white/40 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                  <Sparkle size={14} className="text-blush-500" />
                  Added by you
                </div>
              ) : null}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

