export function Footer() {
  return (
    <footer className="py-10">
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl border border-white/60 bg-white/40 p-6 text-center text-sm text-slate-600 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/5 dark:text-slate-300">
          <div className="font-semibold text-slate-900 dark:text-white">Made with TRAE</div>
          <div className="mt-1">
            Built with React, Tailwind CSS, and Framer Motion — for the moms who made us who we are.
          </div>
        </div>
      </div>
    </footer>
  );
}

