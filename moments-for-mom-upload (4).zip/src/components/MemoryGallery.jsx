import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, ImagePlus, X } from "lucide-react";
import { cn } from "../lib/utils";

function makePlaceholderSvg(seed) {
  const palettes = [
    ["#ff9bbf", "#c0b3ff", "#b2ffe7"],
    ["#ffc2d7", "#a089ff", "#dbfff4"],
    ["#ff6aa0", "#865eff", "#17f2ad"],
  ];
  const [a, b, c] = palettes[seed % palettes.length];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${a}"/>
      <stop offset="0.55" stop-color="${b}"/>
      <stop offset="1" stop-color="${c}"/>
    </linearGradient>
    <filter id="blur">
      <feGaussianBlur stdDeviation="35"/>
    </filter>
  </defs>
  <rect width="800" height="600" fill="url(#g)"/>
  <circle cx="180" cy="170" r="140" fill="rgba(255,255,255,.35)" filter="url(#blur)"/>
  <circle cx="660" cy="240" r="170" fill="rgba(255,255,255,.25)" filter="url(#blur)"/>
  <circle cx="420" cy="520" r="190" fill="rgba(255,255,255,.18)" filter="url(#blur)"/>
  <text x="50%" y="52%" text-anchor="middle" font-family="system-ui,Segoe UI" font-size="44" fill="rgba(255,255,255,.92)">Memory</text>
  <text x="50%" y="62%" text-anchor="middle" font-family="system-ui,Segoe UI" font-size="18" fill="rgba(255,255,255,.85)">Moments For Mom</text>
</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export function MemoryGallery() {
  const inputRef = useRef(null);
  const [images, setImages] = useState([]);
  const [active, setActive] = useState(null);

  const placeholders = useMemo(
    () =>
      Array.from({ length: 6 }).map((_, i) => ({
        id: `ph-${i}`,
        url: makePlaceholderSvg(i),
        name: "A placeholder memory",
        placeholder: true,
      })),
    []
  );

  const grid = images.length ? images : placeholders;
  const activeIndex = active ? grid.findIndex((x) => x.id === active.id) : -1;

  function onPickFiles(files) {
    const next = Array.from(files).map((f) => ({
      id: `${f.name}-${f.size}-${f.lastModified}-${Math.random().toString(16).slice(2)}`,
      url: URL.createObjectURL(f),
      name: f.name,
    }));
    setImages((prev) => [...next, ...prev]);
  }

  function openLightbox(img) {
    setActive(img);
  }

  function closeLightbox() {
    setActive(null);
  }

  function next() {
    if (!active) return;
    const idx = activeIndex;
    const n = (idx + 1) % grid.length;
    setActive(grid[n]);
  }

  function prev() {
    if (!active) return;
    const idx = activeIndex;
    const n = (idx - 1 + grid.length) % grid.length;
    setActive(grid[n]);
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="text-left">
          <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Photo Memory Gallery</h3>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            Upload your favorite moments — click any photo for a lightbox preview.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.length) onPickFiles(e.target.files);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="group relative inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-4 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60"
          >
            <ImagePlus size={18} />
            Upload photos
            <span className="absolute inset-0 rounded-full opacity-0 transition-opacity group-hover:opacity-100">
              <span className="shine absolute inset-0 rounded-full" />
            </span>
          </button>
          {images.length ? (
            <button
              type="button"
              onClick={() => setImages([])}
              className="rounded-full border border-white/50 bg-white/50 px-4 py-2.5 text-sm font-semibold text-slate-800 shadow-sm backdrop-blur transition hover:bg-white/70 dark:border-white/10 dark:bg-white/5 dark:text-white"
            >
              Clear
            </button>
          ) : null}
        </div>
      </div>

      <div className="mt-7 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        {grid.map((img, i) => (
          <motion.button
            key={img.id}
            type="button"
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.45, delay: i * 0.03 }}
            onClick={() => openLightbox(img)}
            className={cn(
              "group relative aspect-[4/3] overflow-hidden rounded-2xl border border-white/60 bg-white/40 shadow-sm backdrop-blur transition hover:-translate-y-1 hover:shadow-glow focus:outline-none focus-visible:ring-2 focus-visible:ring-lavender-400/50 dark:border-white/10 dark:bg-white/5 dark:hover:shadow-glowDark",
              img.placeholder ? "cursor-pointer" : ""
            )}
          >
            <img
              src={img.url}
              alt={img.name || "Memory"}
              className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-black/0 to-black/0 opacity-0 transition-opacity group-hover:opacity-100" />
            <div className="absolute bottom-2 left-2 right-2 truncate text-left text-xs font-medium text-white/90 opacity-0 transition-opacity group-hover:opacity-100">
              {img.placeholder ? "Add your own photos ✨" : img.name}
            </div>
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {active ? (
          <motion.div
            className="fixed inset-0 z-50 grid place-items-center bg-slate-950/55 p-4 backdrop-blur"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeLightbox}
          >
            <motion.div
              className="relative w-full max-w-4xl overflow-hidden rounded-3xl border border-white/15 bg-slate-900/40 shadow-2xl"
              initial={{ scale: 0.96, y: 18, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.98, y: 10, opacity: 0 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              onClick={(e) => e.stopPropagation()}
            >
              <img src={active.url} alt={active.name} className="max-h-[75vh] w-full object-contain bg-black/30" />
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-gradient-to-t from-black/70 to-black/0 p-4">
                <div className="truncate text-left text-sm font-medium text-white/90">
                  {active.placeholder ? "Upload photos to make it yours" : active.name}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={prev}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white transition hover:bg-white/20"
                    aria-label="Previous"
                  >
                    <ChevronLeft size={18} />
                  </button>
                  <button
                    type="button"
                    onClick={next}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white transition hover:bg-white/20"
                    aria-label="Next"
                  >
                    <ChevronRight size={18} />
                  </button>
                  <button
                    type="button"
                    onClick={closeLightbox}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white transition hover:bg-white/20"
                    aria-label="Close"
                  >
                    <X size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}

