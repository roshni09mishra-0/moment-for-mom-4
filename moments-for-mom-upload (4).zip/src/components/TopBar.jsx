import { motion } from "framer-motion";
import { Moon, Sun, Volume2, VolumeX, Music2 } from "lucide-react";
import { cn } from "../lib/utils";

function ChipButton({ onClick, className, children, title }) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={cn(
        "group inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/55 px-3.5 py-2 text-sm font-medium text-slate-700 shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:shadow-glow focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-slate-200 dark:hover:shadow-glowDark",
        className
      )}
    >
      {children}
      <span className="absolute inset-0 -z-10 rounded-full opacity-0 transition-opacity group-hover:opacity-100">
        <span className="shine absolute inset-0 rounded-full" />
      </span>
    </button>
  );
}

export function TopBar({ theme, toggleTheme, music, onToggleMusic, onToggleMute }) {
  return (
    <div className="sticky top-0 z-40">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-white/70 to-white/30 backdrop-blur-xl dark:from-slate-950/70 dark:to-slate-950/20" />
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8 py-3">
        <a
          href="#top"
          className="group inline-flex items-center gap-3 rounded-full px-3 py-2 text-sm font-semibold tracking-tight text-slate-900 transition hover:bg-white/50 dark:text-white dark:hover:bg-white/5"
        >
          <span className="relative grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-blush-300 via-lavender-300 to-mint-200 shadow-glow dark:shadow-glowDark">
            <span className="absolute inset-0 rounded-full bg-white/40 blur-md" />
            <span className="relative">❤</span>
          </span>
          <span className="hidden sm:block">
            Moments <span className="text-slate-500 dark:text-slate-400">For</span> Mom
          </span>
        </a>

        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex items-center gap-2"
        >
          <div className="hidden md:flex items-center gap-1.5 pr-2">
            {[
              ["Gallery", "#gallery"],
              ["Reasons", "#reasons"],
              ["Timeline", "#timeline"],
              ["Poem", "#poem"],
              ["Card", "#card"],
            ].map(([label, href]) => (
              <a
                key={href}
                href={href}
                className="rounded-full px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-white/50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-white/5 dark:hover:text-white"
              >
                {label}
              </a>
            ))}
          </div>

          <ChipButton
            onClick={toggleTheme}
            title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
          >
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            <span className="hidden sm:inline">{theme === "dark" ? "Light" : "Dark"}</span>
          </ChipButton>

          <ChipButton onClick={onToggleMusic} title={music.enabled ? "Stop background music" : "Play background music"}>
            <Music2 size={16} />
            <span className="hidden sm:inline">{music.enabled ? "Stop" : "Music"}</span>
          </ChipButton>

          <ChipButton
            onClick={onToggleMute}
            title={music.muted ? "Unmute music" : "Mute music"}
            className={!music.enabled ? "opacity-50 pointer-events-none" : ""}
          >
            {music.muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            <span className="hidden sm:inline">{music.muted ? "Muted" : "Mute"}</span>
          </ChipButton>
        </motion.div>
      </div>
    </div>
  );
}

