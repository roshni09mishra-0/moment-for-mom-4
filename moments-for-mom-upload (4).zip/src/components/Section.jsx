import { motion } from "framer-motion";
import { cn } from "../lib/utils";

export function Section({ id, eyebrow, title, subtitle, children, className }) {
  return (
    <section id={id} className={cn("relative scroll-mt-20", className)}>
      <div className="mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mx-auto max-w-3xl text-center"
        >
          {eyebrow ? (
            <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-white/40 bg-white/50 px-4 py-2 text-xs font-medium tracking-wide text-slate-700 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
              <span className="h-2 w-2 rounded-full bg-gradient-to-r from-blush-400 to-lavender-500 shadow-[0_0_20px_rgba(255,63,134,.35)]" />
              {eyebrow}
            </div>
          ) : null}
          {title ? (
            <h2 className="mt-5 text-balance text-3xl sm:text-4xl font-semibold tracking-tight text-slate-900 dark:text-white">
              {title}
            </h2>
          ) : null}
          {subtitle ? (
            <p className="mt-3 text-pretty text-base sm:text-lg text-slate-600 dark:text-slate-300">
              {subtitle}
            </p>
          ) : null}
        </motion.div>

        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}

