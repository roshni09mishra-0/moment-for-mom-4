import { useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import html2canvas from "html2canvas";
import confetti from "canvas-confetti";
import { Download, Share2, Sparkles, Wand2 } from "lucide-react";

const templates = [
  {
    id: "blush",
    name: "Blush Bloom",
    className:
      "bg-[radial-gradient(800px_400px_at_20%_10%,rgba(255,63,134,.35),transparent_60%),radial-gradient(700px_400px_at_90%_20%,rgba(134,94,255,.25),transparent_60%),linear-gradient(135deg,#fff5f8,#ffffff,#f7f5ff)]",
  },
  {
    id: "lavender",
    name: "Lavender Dream",
    className:
      "bg-[radial-gradient(800px_420px_at_10%_10%,rgba(134,94,255,.35),transparent_60%),radial-gradient(700px_420px_at_85%_25%,rgba(255,63,134,.22),transparent_60%),linear-gradient(135deg,#f7f5ff,#ffffff,#f1fffb)]",
  },
  {
    id: "midnight",
    name: "Midnight Glow",
    className:
      "bg-[radial-gradient(800px_420px_at_20%_15%,rgba(255,63,134,.28),transparent_60%),radial-gradient(700px_420px_at_85%_30%,rgba(134,94,255,.25),transparent_60%),linear-gradient(135deg,#020617,#0b1226,#020617)] text-white",
  },
];

function dataUrlToFile(dataUrl, filename) {
  const [meta, content] = dataUrl.split(",");
  const mime = meta.match(/:(.*?);/)?.[1] || "image/png";
  const bin = atob(content);
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new File([arr], filename, { type: mime });
}

export function GreetingCard() {
  const cardRef = useRef(null);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("Mom");
  const [message, setMessage] = useState("Thank you for every quiet sacrifice and every warm hug. I love you.");
  const [templateId, setTemplateId] = useState("blush");
  const [busy, setBusy] = useState(false);

  const template = useMemo(() => templates.find((t) => t.id === templateId) || templates[0], [templateId]);

  function burst() {
    confetti({
      particleCount: 120,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#ff3f86", "#865eff", "#17f2ad", "#ffffff"],
    });
    confetti({
      particleCount: 70,
      spread: 120,
      startVelocity: 35,
      origin: { y: 0.4 },
      colors: ["#ffc2d7", "#c0b3ff", "#b2ffe7"],
    });
  }

  async function renderCard() {
    if (!cardRef.current) return null;
    const canvas = await html2canvas(cardRef.current, {
      backgroundColor: null,
      scale: Math.min(2, window.devicePixelRatio || 1),
    });
    return canvas.toDataURL("image/png");
  }

  async function download() {
    setBusy(true);
    try {
      burst();
      const dataUrl = await renderCard();
      if (!dataUrl) return;
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = `moments-for-mom-card.png`;
      a.click();
    } finally {
      setBusy(false);
    }
  }

  async function share() {
    setBusy(true);
    try {
      burst();
      const dataUrl = await renderCard();
      if (!dataUrl) return;
      const file = dataUrlToFile(dataUrl, "moments-for-mom-card.png");
      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          title: "Moments For Mom",
          text: "A little Mother’s Day card, made with love.",
          files: [file],
        });
      } else {
        // Fallback: download
        const a = document.createElement("a");
        a.href = dataUrl;
        a.download = `moments-for-mom-card.png`;
        a.click();
      }
    } catch {
      // ignore
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">
        <div className="lg:col-span-2 rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5">
          <div className="text-left">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Digital Greeting Card</h3>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
              Customize, celebrate (confetti!), and download/share instantly.
            </p>
          </div>

          <div className="mt-5 space-y-3">
            <input
              value={to}
              onChange={(e) => setTo(e.target.value)}
              placeholder="To (e.g., Mom)"
              className="w-full rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <input
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              placeholder="From (optional)"
              className="w-full rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Your message…"
              rows={5}
              className="w-full resize-none rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {templates.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTemplateId(t.id)}
                  className={`rounded-2xl border px-4 py-3 text-left text-sm font-semibold transition ${
                    templateId === t.id
                      ? "border-slate-900 bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                      : "border-white/60 bg-white/60 text-slate-800 hover:bg-white/70 dark:border-white/10 dark:bg-white/5 dark:text-white"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Sparkles size={16} className={templateId === t.id ? "text-white/90 dark:text-slate-900" : "text-blush-500"} />
                    {t.name}
                  </div>
                </button>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                type="button"
                disabled={busy}
                onClick={download}
                className="group relative inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60 disabled:opacity-60 disabled:hover:translate-y-0"
              >
                <Download size={18} />
                Download
                <span className="absolute inset-0 rounded-2xl opacity-0 transition-opacity group-hover:opacity-100">
                  <span className="shine absolute inset-0 rounded-2xl" />
                </span>
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={share}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-semibold text-slate-900 shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:shadow-glow focus:outline-none focus-visible:ring-2 focus-visible:ring-lavender-400/50 disabled:opacity-60 disabled:hover:translate-y-0 dark:border-white/10 dark:bg-white/5 dark:text-white dark:hover:shadow-glowDark"
              >
                <Share2 size={18} />
                Share
              </button>
            </div>

            <div className="mt-2 text-left text-xs text-slate-500 dark:text-slate-400">
              “Share” uses your device share sheet when available; otherwise it downloads.
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="text-left">
                <div className="text-sm font-semibold text-slate-900 dark:text-white">Live preview</div>
                <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">This is what your mom will see.</div>
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/60 bg-white/50 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                <Wand2 size={14} className="text-blush-500" />
                Premium pastel
              </div>
            </div>

            <div className="mt-5">
              <div
                ref={cardRef}
                className={`relative overflow-hidden rounded-[28px] border border-white/60 shadow-[0_30px_90px_-65px_rgba(255,63,134,.65)] ${template.className}`}
              >
                <div className="absolute inset-0 opacity-60">
                  <div className="absolute -left-16 -top-16 h-56 w-56 rounded-full bg-white/50 blur-2xl" />
                  <div className="absolute -right-16 top-10 h-72 w-72 rounded-full bg-white/35 blur-3xl" />
                  <div className="absolute left-24 -bottom-16 h-64 w-64 rounded-full bg-white/30 blur-3xl" />
                </div>

                <div className="relative p-8 sm:p-10">
                  <div className="flex items-start justify-between gap-4">
                    <div className="text-left">
                      <div className="text-xs font-semibold opacity-80">To</div>
                      <div className="mt-1 text-2xl sm:text-3xl font-semibold tracking-tight">{to || "Mom"}</div>
                    </div>
                    <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/50 shadow-sm backdrop-blur">
                      <span className="text-2xl">💝</span>
                    </div>
                  </div>

                  <div className="mt-7 text-left">
                    <div className="text-sm sm:text-base leading-relaxed opacity-90 whitespace-pre-wrap">
                      {message || "Write something beautiful…"}
                    </div>
                  </div>

                  <div className="mt-8 flex items-center justify-between gap-3">
                    <div className="text-left text-xs font-semibold opacity-75">{from ? `From ${from}` : "Made with love"}</div>
                    <div className="text-xs font-semibold opacity-75">Happy Mother’s Day</div>
                  </div>

                  <div className="mt-6 h-px bg-white/60" />
                  <div className="mt-4 flex items-center justify-between text-[11px] font-semibold opacity-75">
                    <span>Moments For Mom</span>
                    <span>❤️</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

