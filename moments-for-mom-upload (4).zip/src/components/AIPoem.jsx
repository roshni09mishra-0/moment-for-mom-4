import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Copy, Sparkles, Wand2 } from "lucide-react";

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function generatePoem({ momName, qualities, memory, tone }) {
  const name = momName?.trim() || "Mom";
  const q = qualities?.trim();
  const m = memory?.trim();

  const openers = [
    `Dear ${name},`,
    `${name},`,
    `To my ${name},`,
    `My sweet ${name},`,
  ];

  const linesSoft = [
    "You are the warm light that never asks for anything back,",
    "the kind of love that makes a home out of a heartbeat.",
    "When the world is loud, you become my quiet.",
    "Your hands have carried more hope than I can name.",
  ];

  const linesProud = [
    "You taught me how to stand gently and still be strong,",
    "how to keep going — with kindness in my fists.",
    "I’m proud of the love you choose every day.",
    "I’m proud of the woman you’ve always been.",
  ];

  const closers = [
    "Today and always, thank you.",
    "With all my love — now and forever.",
    "I love you more than words can hold.",
    "Forever your child, forever grateful.",
  ];

  const signature = [
    "— Your biggest fan",
    "— With love",
    "— Always",
    "— From my heart",
  ];

  const flavor = tone === "proud" ? linesProud : linesSoft;

  const detail1 = q ? `You are ${q}.` : pick(["You are my peace.", "You are my strength.", "You are my soft place to land."]);
  const detail2 = m
    ? `I still remember: “${m}”.`
    : pick([
        "I still remember your voice saying “it’s okay, I’m here.”",
        "I still remember the way you made ordinary days feel safe.",
        "I still remember the small things you did that meant everything.",
      ]);

  const poem = [
    pick(openers),
    "",
    pick(flavor),
    detail1,
    detail2,
    "If I could fold my gratitude into a ribbon,",
    "I’d tie it around your day — and make it shine.",
    "",
    pick(closers),
    pick(signature),
  ].join("\n");

  return poem;
}

export function AIPoem() {
  const [momName, setMomName] = useState("");
  const [qualities, setQualities] = useState("");
  const [memory, setMemory] = useState("");
  const [tone, setTone] = useState("soft");
  const [poem, setPoem] = useState(() => generatePoem({ tone: "soft" }));
  const [copied, setCopied] = useState(false);

  const badge = useMemo(() => (tone === "soft" ? "Soft & tender" : "Proud & strong"), [tone]);

  function create() {
    setPoem(
      generatePoem({
        momName,
        qualities,
        memory,
        tone,
      })
    );
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(poem);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      // ignore
    }
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">
        <div className="lg:col-span-2 rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5">
          <div className="text-left">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">AI‑Generated Poem</h3>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
              A sweet poem, crafted from your words (runs fully in-browser).
            </p>
          </div>

          <div className="mt-5 space-y-3">
            <input
              value={momName}
              onChange={(e) => setMomName(e.target.value)}
              placeholder="Mom’s name (optional)"
              className="w-full rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <input
              value={qualities}
              onChange={(e) => setQualities(e.target.value)}
              placeholder="Describe her in a few words (e.g., brave, gentle, unstoppable)"
              className="w-full rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />
            <textarea
              value={memory}
              onChange={(e) => setMemory(e.target.value)}
              placeholder="A memory you love (optional)"
              rows={4}
              className="w-full resize-none rounded-2xl border border-white/60 bg-white/60 px-4 py-3 text-sm font-medium text-slate-900 shadow-sm backdrop-blur placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/50 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-slate-400"
            />

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setTone("soft")}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                  tone === "soft"
                    ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                    : "border border-white/60 bg-white/60 text-slate-800 hover:bg-white/70 dark:border-white/10 dark:bg-white/5 dark:text-white"
                }`}
              >
                Soft
              </button>
              <button
                type="button"
                onClick={() => setTone("proud")}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition ${
                  tone === "proud"
                    ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                    : "border border-white/60 bg-white/60 text-slate-800 hover:bg-white/70 dark:border-white/10 dark:bg-white/5 dark:text-white"
                }`}
              >
                Proud
              </button>
              <span className="ml-auto inline-flex items-center gap-2 rounded-full border border-white/60 bg-white/50 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                <Sparkles size={14} className="text-blush-500" />
                {badge}
              </span>
            </div>

            <button
              type="button"
              onClick={create}
              className="group relative inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blush-500 via-lavender-500 to-mint-400 px-4 py-3 text-sm font-semibold text-white shadow-glow transition hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-blush-400/60"
            >
              <Wand2 size={18} />
              Generate poem
              <span className="absolute inset-0 rounded-2xl opacity-0 transition-opacity group-hover:opacity-100">
                <span className="shine absolute inset-0 rounded-2xl" />
              </span>
            </button>
          </div>
        </div>

        <div className="lg:col-span-3 rounded-3xl border border-white/60 bg-white/50 shadow-sm backdrop-blur p-6 sm:p-7 dark:border-white/10 dark:bg-white/5">
          <div className="flex items-center justify-between gap-3">
            <div className="text-left">
              <div className="text-sm font-semibold text-slate-900 dark:text-white">Your poem</div>
              <div className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                You can copy it, edit it, or paste into your greeting card.
              </div>
            </div>
            <button
              type="button"
              onClick={copy}
              className="inline-flex items-center gap-2 rounded-full border border-white/60 bg-white/60 px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:shadow-glow dark:border-white/10 dark:bg-white/5 dark:text-white dark:hover:shadow-glowDark"
            >
              <Copy size={16} />
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>

          <motion.pre
            key={poem}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: "easeOut" }}
            className="mt-5 whitespace-pre-wrap rounded-3xl border border-white/60 bg-white/60 p-6 text-left text-sm leading-relaxed text-slate-800 shadow-inner backdrop-blur dark:border-white/10 dark:bg-white/5 dark:text-slate-100"
          >
            {poem}
          </motion.pre>
        </div>
      </div>
    </div>
  );
}

